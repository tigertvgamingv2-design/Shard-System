package com.thronecraft.examples.advanced.homes;

import com.thronecraft.examples.advanced.AdvancedShardSupport;
import com.thronecraft.net.shards.ShardModule;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HomesShard implements ShardModule, CommandExecutor, TabCompleter {
    private static final int MAX_HOMES = 5;
    private static final String DATA_FILE = "homes.yml";
    private final List<PluginCommand> commands = new ArrayList<>();
    private JavaPlugin plugin;
    private YamlConfiguration data;

    @Override
    public void onEnable(JavaPlugin plugin) {
        this.plugin = plugin;
        data = AdvancedShardSupport.loadData(plugin, DATA_FILE);
        commands.add(AdvancedShardSupport.register(plugin, "sethome", this));
        commands.add(AdvancedShardSupport.register(plugin, "home", this));
        commands.add(AdvancedShardSupport.register(plugin, "homes", this));
        commands.add(AdvancedShardSupport.register(plugin, "delhome", this));
    }

    @Override
    public void onDisable() {
        for (PluginCommand command : commands) {
            AdvancedShardSupport.unregister(command, this);
        }
        commands.clear();
        if (data != null) {
            AdvancedShardSupport.saveData(plugin, data, DATA_FILE);
            data = null;
        }
        plugin = null;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player player = AdvancedShardSupport.requirePlayer(sender);
        if (player == null) {
            return true;
        }
        String commandName = command.getName().toLowerCase(Locale.ROOT);
        switch (commandName) {
            case "sethome" -> setHome(player, args);
            case "home" -> teleportHome(player, args);
            case "homes" -> listHomes(player);
            case "delhome" -> deleteHome(player, args);
            default -> AdvancedShardSupport.send(sender, "&cUnknown homes command.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && (command.getName().equalsIgnoreCase("home")
                || command.getName().equalsIgnoreCase("delhome"))) {
            return AdvancedShardSupport.matching(homeNames(sender), args[0]);
        }
        return List.of();
    }

    private void setHome(Player player, String[] args) {
        if (args.length > 1) {
            usage(player, "/sethome [name]");
            return;
        }
        String name = args.length == 0 ? "home" : args[0];
        if (!AdvancedShardSupport.validName(name)) {
            AdvancedShardSupport.send(player, "&cNames must be 1-16 letters, numbers, _ or -.");
            return;
        }
        String base = AdvancedShardSupport.playerPath(player.getUniqueId());
        List<String> homes = AdvancedShardSupport.keys(data.getConfigurationSection(base));
        if (!homes.contains(name) && homes.size() >= MAX_HOMES
                && !player.hasPermission("shard.homes.unlimited")) {
            AdvancedShardSupport.send(player, "&cYou have reached the " + MAX_HOMES + " home limit.");
            return;
        }
        AdvancedShardSupport.writeLocation(data, base + "." + name, player.getLocation());
        save();
        AdvancedShardSupport.send(player, "&aSaved home &f" + name + "&a.");
    }

    private void teleportHome(Player player, String[] args) {
        if (args.length > 1) {
            usage(player, "/home [name]");
            return;
        }
        String name = args.length == 0 ? "home" : args[0];
        Location location = AdvancedShardSupport.readLocation(
                data, AdvancedShardSupport.playerPath(player.getUniqueId()) + "." + name);
        if (location == null) {
            AdvancedShardSupport.send(player, "&cHome not found or its world is unavailable: &f" + name);
            return;
        }
        if (player.teleport(location)) {
            AdvancedShardSupport.send(player, "&aTeleported to home &f" + name + "&a.");
        } else {
            AdvancedShardSupport.send(player, "&cCould not teleport you to that home.");
        }
    }

    private void listHomes(Player player) {
        List<String> homes = AdvancedShardSupport.keys(
                data.getConfigurationSection(AdvancedShardSupport.playerPath(player.getUniqueId())));
        if (homes.isEmpty()) {
            AdvancedShardSupport.send(player, "&7You have no homes. Use &f/sethome [name]&7.");
            return;
        }
        AdvancedShardSupport.send(player, "&7Homes (&f" + homes.size() + "/" + MAX_HOMES + "&7): &f"
                + String.join("&7, &f", homes));
    }

    private void deleteHome(Player player, String[] args) {
        if (args.length != 1) {
            usage(player, "/delhome <name>");
            return;
        }
        if (!AdvancedShardSupport.validName(args[0])) {
            AdvancedShardSupport.send(player, "&cInvalid home name.");
            return;
        }
        String path = AdvancedShardSupport.playerPath(player.getUniqueId()) + "." + args[0];
        if (!data.contains(path)) {
            AdvancedShardSupport.send(player, "&cHome not found: &f" + args[0]);
            return;
        }
        data.set(path, null);
        save();
        AdvancedShardSupport.send(player, "&aDeleted home &f" + args[0] + "&a.");
    }

    private List<String> homeNames(CommandSender sender) {
        if (sender instanceof Player player) {
            return AdvancedShardSupport.keys(data.getConfigurationSection(
                    AdvancedShardSupport.playerPath(player.getUniqueId())));
        }
        return List.of();
    }

    private void save() {
        AdvancedShardSupport.saveData(plugin, data, DATA_FILE);
    }

    private void usage(CommandSender sender, String usage) {
        AdvancedShardSupport.send(sender, "&cUsage: " + usage);
    }
}
