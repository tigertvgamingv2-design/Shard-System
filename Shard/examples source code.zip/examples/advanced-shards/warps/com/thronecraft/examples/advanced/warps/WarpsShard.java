package com.thronecraft.examples.advanced.warps;

import com.thronecraft.examples.advanced.AdvancedShardSupport;
import com.thronecraft.net.shards.ShardModule;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public class WarpsShard implements ShardModule, CommandExecutor, TabCompleter {
    private static final String DATA_FILE = "warps.yml";
    private final List<PluginCommand> commands = new ArrayList<>();
    private JavaPlugin plugin;
    private YamlConfiguration data;

    @Override
    public void onEnable(JavaPlugin plugin) {
        this.plugin = plugin;
        data = AdvancedShardSupport.loadData(plugin, DATA_FILE);
        commands.add(AdvancedShardSupport.register(plugin, "warp", this));
        commands.add(AdvancedShardSupport.register(plugin, "warps", this));
        commands.add(AdvancedShardSupport.register(plugin, "setwarp", this));
        commands.add(AdvancedShardSupport.register(plugin, "delwarp", this));
    }

    @Override
    public void onDisable() {
        for (PluginCommand command : commands) {
            AdvancedShardSupport.unregister(command, this);
        }
        commands.clear();
        if (data != null) {
            AdvancedShardSupport.saveData(plugin, data, DATA_FILE);
            data = null;
        }
        plugin = null;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String commandName = command.getName().toLowerCase(java.util.Locale.ROOT);
        switch (commandName) {
            case "warp" -> teleport(sender, args);
            case "warps" -> listWarps(sender);
            case "setwarp" -> setWarp(sender, args);
            case "delwarp" -> deleteWarp(sender, args);
            default -> AdvancedShardSupport.send(sender, "&cUnknown warp command.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && command.getName().equalsIgnoreCase("warp")) {
            return AdvancedShardSupport.matching(
                    AdvancedShardSupport.keys(data.getConfigurationSection("warps")), args[0]);
        }
        return List.of();
    }

    private void teleport(CommandSender sender, String[] args) {
        Player player = AdvancedShardSupport.requirePlayer(sender);
        if (player == null) {
            return;
        }
        if (args.length != 1) {
            usage(player, "/warp <name>");
            return;
        }
        if (!AdvancedShardSupport.validName(args[0])) {
            AdvancedShardSupport.send(player, "&cInvalid warp name.");
            return;
        }
        Location location = AdvancedShardSupport.readLocation(data, "warps." + args[0]);
        if (location == null) {
            AdvancedShardSupport.send(player, "&cWarp not found or its world is unavailable: &f" + args[0]);
            return;
        }
        if (player.teleport(location)) {
            AdvancedShardSupport.send(player, "&aTeleported to warp &f" + args[0] + "&a.");
        } else {
            AdvancedShardSupport.send(player, "&cCould not teleport you to that warp.");
        }
    }

    private void listWarps(CommandSender sender) {
        List<String> warps = AdvancedShardSupport.keys(data.getConfigurationSection("warps"));
        if (warps.isEmpty()) {
            AdvancedShardSupport.send(sender, "&7No warps have been created yet.");
            return;
        }
        AdvancedShardSupport.send(sender, "&7Warps (&f" + warps.size() + "&7): &f"
                + String.join("&7, &f", warps));
    }

    private void setWarp(CommandSender sender, String[] args) {
        Player player = AdvancedShardSupport.requirePlayer(sender);
        if (player == null) {
            return;
        }
        if (!sender.hasPermission("shard.warps.admin")) {
            AdvancedShardSupport.send(sender, "&cYou need shard.warps.admin to create warps.");
            return;
        }
        if (args.length != 1 || !AdvancedShardSupport.validName(args[0])) {
            usage(sender, "/setwarp <name>");
            return;
        }
        AdvancedShardSupport.writeLocation(data, "warps." + args[0], player.getLocation());
        save();
        AdvancedShardSupport.send(sender, "&aSaved warp &f" + args[0] + "&a.");
    }

    private void deleteWarp(CommandSender sender, String[] args) {
        if (!sender.hasPermission("shard.warps.admin")) {
            AdvancedShardSupport.send(sender, "&cYou need shard.warps.admin to delete warps.");
            return;
        }
        if (args.length != 1 || !AdvancedShardSupport.validName(args[0])
                || !data.contains("warps." + args[0])) {
            usage(sender, "/delwarp <name>");
            return;
        }
        data.set("warps." + args[0], null);
        save();
        AdvancedShardSupport.send(sender, "&aDeleted warp &f" + args[0] + "&a.");
    }

    private void save() {
        AdvancedShardSupport.saveData(plugin, data, DATA_FILE);
    }

    private void usage(CommandSender sender, String usage) {
        AdvancedShardSupport.send(sender, "&cUsage: " + usage);
    }
}
