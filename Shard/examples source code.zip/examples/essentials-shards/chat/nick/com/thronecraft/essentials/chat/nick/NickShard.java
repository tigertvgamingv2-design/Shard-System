package com.thronecraft.essentials.chat.nick;

import com.thronecraft.net.shards.ShardModule;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;

public class NickShard implements ShardModule, CommandExecutor {
    private PluginCommand command; private Permission permission;
    @Override public void onEnable(JavaPlugin plugin) { permission=registerPermission(); command=plugin.getCommand("nick"); if(command==null) throw new IllegalStateException("Missing /nick command"); command.setExecutor(this); }
    @Override public void onDisable() { if(command!=null && command.getExecutor()==this) command.setExecutor(null); command=null; permission=null; }
    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if(!sender.hasPermission("shard.essentials.nick")) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"You lack permission."); return true; }
        if(!(sender instanceof Player player)) { com.thronecraft.net.shards.ShardMessages.send(sender, "Only players can use /nick."); return true; }
        if(args.length>1) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"Usage: /nick [name|off]"); return true; }
        if(args.length==0 || args[0].equalsIgnoreCase("off")) {
            player.setDisplayName(player.getName()); player.setPlayerListName(player.getName());
            com.thronecraft.net.shards.ShardMessages.send(player, ChatColor.GREEN+"Nickname reset."); return true;
        }
        String raw=args[0];
        if(raw.length()>32 || !raw.matches("[A-Za-z0-9_&]{1,32}")) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"Nicknames may contain only letters, numbers, underscores, and color codes; maximum 16 visible characters."); return true; }
        if(raw.replaceAll("(?i)&[0-9a-fk-or]", "").contains("&")) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"Invalid nickname color code."); return true; }
        String visible=ChatColor.stripColor(ChatColor.translateAlternateColorCodes('&',raw));
        if(visible==null || visible.isBlank() || visible.length()>16) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"Nicknames must have 1-16 visible characters."); return true; }
        String nick=ChatColor.translateAlternateColorCodes('&',raw);
        player.setDisplayName(nick); player.setPlayerListName(nick); com.thronecraft.net.shards.ShardMessages.send(player, ChatColor.GREEN+"Nickname set to "+nick+ChatColor.GREEN+".");
        return true;
    }
    private Permission registerPermission() { String n="shard.essentials.nick"; Permission old=Bukkit.getPluginManager().getPermission(n); if(old!=null)return old; Permission p=new Permission(n,PermissionDefault.TRUE); Bukkit.getPluginManager().addPermission(p); return p; }
}
