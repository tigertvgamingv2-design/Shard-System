package com.thronecraft.essentials.chat.mail;

import com.thronecraft.net.shards.ShardModule;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MailShard implements ShardModule, CommandExecutor {
    private JavaPlugin plugin; private PluginCommand command; private Permission permission;
    @Override public void onEnable(JavaPlugin p) { plugin=p; permission=registerPermission(); command=p.getCommand("mail"); if(command==null) throw new IllegalStateException("Missing /mail command"); command.setExecutor(this); }
    @Override public void onDisable() { if(command!=null && command.getExecutor()==this) command.setExecutor(null); command=null; permission=null; plugin=null; }
    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if(!sender.hasPermission("shard.essentials.mail")) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"You lack permission."); return true; }
        if(!(sender instanceof Player player)) { com.thronecraft.net.shards.ShardMessages.send(sender, "Only players can use /mail."); return true; }
        if(args.length<3 || !args[0].equalsIgnoreCase("send")) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"Usage: /mail send <player> <message...>"); return true; }
        String recipient=args[1];
        if(!recipient.matches("[A-Za-z0-9_]{1,16}")) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"Invalid player name."); return true; }
        OfflinePlayer target=Bukkit.getOfflinePlayer(recipient);
        if(target.getUniqueId()==null) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"Could not find that player."); return true; }
        String body=String.join(" ", java.util.Arrays.copyOfRange(args,2,args.length));
        YamlConfiguration data=load(); String path="mail."+target.getUniqueId(); List<String> messages=new ArrayList<>(data.getStringList(path));
        if(messages.size()>=100) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"That player's mailbox is full."); return true; }
        messages.add(System.currentTimeMillis()+"|"+player.getName()+"|"+body);
        data.set(path,messages); save(data); com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.GREEN+"Mail sent to "+recipient+".");
        Player online=target.getPlayer(); if(online!=null) com.thronecraft.net.shards.ShardMessages.send(online, ChatColor.YELLOW+"You have new mail. Use /mailread.");
        return true;
    }
    private Permission registerPermission() { String n="shard.essentials.mail"; Permission old=Bukkit.getPluginManager().getPermission(n); if(old!=null)return old; Permission p=new Permission(n,PermissionDefault.TRUE); Bukkit.getPluginManager().addPermission(p); return p; }
    private YamlConfiguration load() { return YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(),"chat.yml")); }
    private void save(YamlConfiguration d) { try { d.save(new File(plugin.getDataFolder(),"chat.yml")); } catch(Exception e) { plugin.getLogger().warning("Could not save chat.yml: "+e.getMessage()); } }
}
