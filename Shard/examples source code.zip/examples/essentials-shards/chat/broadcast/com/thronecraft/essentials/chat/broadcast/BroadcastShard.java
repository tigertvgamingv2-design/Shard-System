package com.thronecraft.essentials.chat.broadcast;

import com.thronecraft.net.shards.ShardModule;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;

public class BroadcastShard implements ShardModule, CommandExecutor {
    private PluginCommand command; private Permission permission;
    @Override public void onEnable(JavaPlugin plugin) {
        permission=registerPermission(); command=plugin.getCommand("broadcast");
        if(command==null) throw new IllegalStateException("Missing /broadcast command");
        command.setExecutor(this);
    }
    @Override public void onDisable() {
        if(command!=null && command.getExecutor()==this) command.setExecutor(null);
        command=null; permission=null;
    }
    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if(!sender.hasPermission("shard.essentials.broadcast")) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"You lack permission."); return true; }
        if(args.length==0) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"Usage: /broadcast <message...>"); return true; }
        String text=ChatColor.translateAlternateColorCodes('&',String.join(" ",args));
        com.thronecraft.net.shards.ShardMessages.broadcast(ChatColor.GOLD+"[Broadcast] "+ChatColor.RESET+text);
        return true;
    }
    private Permission registerPermission() { String n="shard.essentials.broadcast"; Permission old=Bukkit.getPluginManager().getPermission(n); if(old!=null)return old; Permission p=new Permission(n,PermissionDefault.OP); Bukkit.getPluginManager().addPermission(p); return p; }
}
