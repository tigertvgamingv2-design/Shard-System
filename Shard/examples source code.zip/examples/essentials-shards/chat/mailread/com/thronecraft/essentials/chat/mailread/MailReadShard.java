package com.thronecraft.essentials.chat.mailread;

import com.thronecraft.net.shards.ShardModule;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.File;
import java.util.List;

public class MailReadShard implements ShardModule, CommandExecutor {
    private JavaPlugin plugin; private PluginCommand command; private Permission permission;
    @Override public void onEnable(JavaPlugin p) { plugin=p; permission=registerPermission(); command=p.getCommand("mailread"); if(command==null) throw new IllegalStateException("Missing /mailread command"); command.setExecutor(this); }
    @Override public void onDisable() { if(command!=null && command.getExecutor()==this) command.setExecutor(null); command=null; permission=null; plugin=null; }
    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if(!sender.hasPermission("shard.essentials.mailread")) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"You lack permission."); return true; }
        if(!(sender instanceof Player player)) { com.thronecraft.net.shards.ShardMessages.send(sender, "Only players can use /mailread."); return true; }
        if(args.length>1 || (args.length==1 && !args[0].equalsIgnoreCase("clear"))) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"Usage: /mailread [clear]"); return true; }
        YamlConfiguration data=load(); String path="mail."+player.getUniqueId(); List<String> messages=data.getStringList(path);
        if(args.length==1) {
            if(!args[0].equalsIgnoreCase("clear")) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"Usage: /mailread [clear]"); return true; }
            data.set(path,null); save(data); com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.GREEN+"Mailbox cleared."); return true;
        }
        if(messages.isEmpty()) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.GRAY+"Your mailbox is empty."); return true; }
        com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.GOLD+"Mail ("+messages.size()+"):");
        for(String entry:messages) {
            String[] fields=entry.split("\\|",3);
            if(fields.length==3) com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.YELLOW+"["+fields[1]+"] "+ChatColor.WHITE+fields[2]);
            else com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.WHITE+entry);
        }
        return true;
    }
    private Permission registerPermission() { String n="shard.essentials.mailread"; Permission old=Bukkit.getPluginManager().getPermission(n); if(old!=null)return old; Permission p=new Permission(n,PermissionDefault.TRUE); Bukkit.getPluginManager().addPermission(p); return p; }
    private YamlConfiguration load() { return YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(),"chat.yml")); }
    private void save(YamlConfiguration d) { try { d.save(new File(plugin.getDataFolder(),"chat.yml")); } catch(Exception e) { plugin.getLogger().warning("Could not save chat.yml: "+e.getMessage()); } }
}
