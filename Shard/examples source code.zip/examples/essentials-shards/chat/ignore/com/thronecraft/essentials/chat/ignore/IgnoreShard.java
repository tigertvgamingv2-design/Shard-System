package com.thronecraft.essentials.chat.ignore;

import com.thronecraft.net.shards.ShardModule;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class IgnoreShard implements ShardModule, CommandExecutor {
    private JavaPlugin plugin; private PluginCommand command; private Permission permission;
    @Override public void onEnable(JavaPlugin p) { plugin=p; permission=registerPermission(); command=p.getCommand("ignore"); if(command==null) throw new IllegalStateException("Missing /ignore command"); command.setExecutor(this); }
    @Override public void onDisable() { if(command!=null && command.getExecutor()==this) command.setExecutor(null); command=null; permission=null; plugin=null; }
    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if(!sender.hasPermission("shard.essentials.ignore")) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"You lack permission."); return true; }
        if(!(sender instanceof Player player)) { com.thronecraft.net.shards.ShardMessages.send(sender, "Only players can use /ignore."); return true; }
        if(args.length!=1) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"Usage: /ignore <player>"); return true; }
        Player target=Bukkit.getPlayerExact(args[0]); if(target==null) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"That player is not online."); return true; }
        if(target.equals(player)) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED+"You cannot ignore yourself."); return true; }
        YamlConfiguration data=load(); String path="ignored."+player.getUniqueId(); List<String> ids=new ArrayList<>(data.getStringList(path));
        if(ids.contains(target.getUniqueId().toString())) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.YELLOW+"You already ignore "+target.getName()+"."); return true; }
        ids.add(target.getUniqueId().toString()); data.set(path,ids); save(data); com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.GREEN+"Now ignoring "+target.getName()+"."); return true;
    }
    private Permission registerPermission() { String n="shard.essentials.ignore"; Permission old=Bukkit.getPluginManager().getPermission(n); if(old!=null)return old; Permission p=new Permission(n,PermissionDefault.TRUE); Bukkit.getPluginManager().addPermission(p); return p; }
    private YamlConfiguration load() { return YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(),"chat.yml")); }
    private void save(YamlConfiguration d) { try { d.save(new File(plugin.getDataFolder(),"chat.yml")); } catch(Exception e) { plugin.getLogger().warning("Could not save chat.yml: "+e.getMessage()); } }
}
