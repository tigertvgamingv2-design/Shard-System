package com.thronecraft.essentials.chat.reply;

import com.thronecraft.net.shards.ShardModule;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.List;
import java.util.UUID;

public class ReplyShard implements ShardModule, CommandExecutor {
    private JavaPlugin plugin;
    private PluginCommand command;
    private Permission permission;
    @Override public void onEnable(JavaPlugin plugin) {
        this.plugin = plugin;
        permission = permission();
        command = plugin.getCommand("reply");
        if (command == null) throw new IllegalStateException("Missing /reply command in plugin.yml");
        command.setExecutor(this);
    }
    @Override public void onDisable() {
        if (command != null && command.getExecutor() == this) command.setExecutor(null);
        command = null; permission = null; plugin = null;
    }
    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("shard.essentials.reply")) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED + "You lack permission."); return true; }
        if (!(sender instanceof Player player)) { com.thronecraft.net.shards.ShardMessages.send(sender, "Only players can use /reply."); return true; }
        if (args.length < 1) { com.thronecraft.net.shards.ShardMessages.send(sender, ChatColor.RED + "Usage: /reply <message...>"); return true; }
        YamlConfiguration data = load();
        String saved = data.getString("reply." + player.getUniqueId());
        UUID id;
        try { id = UUID.fromString(saved == null ? "" : saved); } catch (IllegalArgumentException ex) { com.thronecraft.net.shards.ShardMessages.send(player, ChatColor.RED + "You have nobody to reply to."); return true; }
        Player target = Bukkit.getPlayer(id);
        if (target == null) { com.thronecraft.net.shards.ShardMessages.send(player, ChatColor.RED + "That player is not online."); return true; }
        if (data.getStringList("ignored." + target.getUniqueId()).contains(player.getUniqueId().toString())) {
            com.thronecraft.net.shards.ShardMessages.send(player, ChatColor.RED + target.getName() + " is ignoring you."); return true;
        }
        String text = String.join(" ", args);
        com.thronecraft.net.shards.ShardMessages.send(player, ChatColor.GRAY + "[you -> " + target.getName() + "] " + ChatColor.WHITE + text);
        com.thronecraft.net.shards.ShardMessages.send(target, ChatColor.GRAY + "[" + player.getName() + " -> you] " + ChatColor.WHITE + text);
        data.set("reply." + player.getUniqueId(), target.getUniqueId().toString());
        data.set("reply." + target.getUniqueId(), player.getUniqueId().toString());
        save(data);
        return true;
    }
    private Permission permission() {
        String node = "shard.essentials.reply";
        Permission existing = Bukkit.getPluginManager().getPermission(node);
        if (existing != null) return existing;
        Permission created = new Permission(node, PermissionDefault.TRUE);
        Bukkit.getPluginManager().addPermission(created);
        return created;
    }
    private YamlConfiguration load() { return YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "chat.yml")); }
    private void save(YamlConfiguration data) { try { data.save(new File(plugin.getDataFolder(), "chat.yml")); } catch (Exception e) { plugin.getLogger().warning("Could not save chat.yml: " + e.getMessage()); } }
}
